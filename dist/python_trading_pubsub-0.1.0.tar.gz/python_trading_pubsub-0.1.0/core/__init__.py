"""Core module for Python Trading PubSub."""
