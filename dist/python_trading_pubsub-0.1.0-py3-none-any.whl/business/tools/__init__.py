"""Tools module for business logic."""
