"""Enumerations for business logic."""
